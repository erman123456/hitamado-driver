package com.example.sjt.data.remote.page

import android.content.Context
import androidx.paging.PageKeyedDataSource
import com.example.sjt.data.remote.RemoteDataSource
import com.example.sjt.model.airline.operational.DataItem
import com.example.sjt.model.airline.operational.Master
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OperationalPageDataSource @Inject constructor(
    private val remoteDataSource: RemoteDataSource,
    private val context: Context
) :
    PageKeyedDataSource<Int, DataItem>() {
    override fun loadInitial(
        params: LoadInitialParams<Int>,
        callback: LoadInitialCallback<Int, DataItem>
    ) {
        remoteDataSource.getResponseAirlineOperational(
            context = context,
            callback = object : RemoteDataSource.LoadResponseAirlineOperationalCallback {
                override fun onGetResponseAirlineOperational(response: Master?) {
                    callback.onResult(response?.data!!, null, response.currentPage)
                }
            })
    }

    override fun loadBefore(params: LoadParams<Int>, callback: LoadCallback<Int, DataItem>) {
    }

    override fun loadAfter(params: LoadParams<Int>, callback: LoadCallback<Int, DataItem>) {
        if (params.key == -1) return

        remoteDataSource.getResponseAirlineOperational(
            context = context,
            page = params.key,
            callback = object : RemoteDataSource.LoadResponseAirlineOperationalCallback {
                override fun onGetResponseAirlineOperational(response: Master?) {
                    callback.onResult(response?.data!!, response.currentPage)
                }
            })
    }
}