package com.example.sjt.ui.delegasi

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.newpo.NewpoEntity
import com.example.sjt.model.siapantar.SiapAntarEntity

class DelegasiViewModel@ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getItemDelegasiPickup(context: Context): LiveData<List<NewpoEntity>> =
        sjtRepository.getResponseDelegasiPickup(context)

    fun getItemDelegasiOffice(context: Context): LiveData<List<NewpoEntity>> =
        sjtRepository.getResponseDelegasiOffice(context)

    fun getItemDelegasiDeliverAirline(context: Context): LiveData<List<SiapAntarEntity>> =
        sjtRepository.getResponseDelegasiDeliverAirline(context)
}