package com.example.sjt.model.office

data class ConfirmEntity(
    val success: Boolean? = null
)