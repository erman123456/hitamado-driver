package com.example.sjt.ui.detail.office.headdriver

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.sjt.R
import com.example.sjt.model.office.OfficeEntity
import kotlinx.android.synthetic.main.activity_detail_head_driver_office.*
import java.text.NumberFormat
import java.util.*

class DetailHeadDriverOfficeActivity : AppCompatActivity(), View.OnClickListener {
    companion object {
        const val EXTRA_DATA = "extra_data"
    }

    private var items: OfficeEntity? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_head_driver_office)
        items = intent.getParcelableExtra(EXTRA_DATA) as OfficeEntity
        populateOffice(items!!)
        btn_back_detail_office_head.setOnClickListener(this)
    }

    private fun populateOffice(item: OfficeEntity) {
        tv_number_po_house.text = item.po_house_number
        tv_customer_name_office_head.text = item.customer_name
        tv_alamat_customer_office_head.text = item.customer_alamt
        tv_telepon_office_head.text = item.no_telepon
        tv_marketing_office_head.text = item.marketing_name
        tv_komoditi_office_head.text = item.comodity_name
        tv_berat_benda_office_head.text =
            NumberFormat.getNumberInstance(Locale.GERMAN).format(item.quantity_est?.toInt())
                .toString()
        tv_collie_office_head.text = item.collie_est
        tv_driver_name_office_head.text = item.driverName
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.btn_back_detail_office_head -> {
                finish()
            }
        }
    }
}