package com.example.sjt.model.delegasi

data class DelegasiEntity(
    val success: Boolean? = null,
    val error: Boolean? = null
)