package com.example.sjt.ui.delegasi.search.deliverairline

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.siapantar.SiapAntarEntity

class SearchDelegasiDeliverAirlineViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getItemDelegasiDeliverAirline(context: Context): LiveData<List<SiapAntarEntity>> =
        sjtRepository.getResponseDelegasiDeliverAirline(context)
}