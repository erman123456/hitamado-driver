package com.example.sjt.model.pickup

data class ContinuePickupEntity(
    val success: Boolean? = null
)