package com.example.sjt.ui.detail.search.deliverAirline.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.sjt.R
import com.example.sjt.model.deliverairline.DeliverAirlineEntity
import kotlinx.android.synthetic.main.item_deliver_airline.view.*

class SearchDeliverAirlineItemAdapter :
    RecyclerView.Adapter<SearchDeliverAirlineItemAdapter.SearchItemViewHolder>() {
    private var onItemClickCallback: OnItemClickCallback? = null
    private var listItems = ArrayList<DeliverAirlineEntity>()

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    fun setListItems(listData: List<DeliverAirlineEntity>?) {
        if (listData == null) return
        listItems.clear()
        listItems.addAll(listData)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SearchDeliverAirlineItemAdapter.SearchItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_deliver_airline, parent, false)
        return SearchItemViewHolder(view)
    }

    override fun getItemCount(): Int = listItems.size

    override fun onBindViewHolder(
        holder: SearchDeliverAirlineItemAdapter.SearchItemViewHolder,
        position: Int
    ) {
        val item = listItems[position]
        holder.bind(item)
    }

    inner class SearchItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(item: DeliverAirlineEntity) {
            with(itemView) {
                tv_po_master_number.text = item.po_master_number
                val date=item.dateDelivery?.split(" ")
                tv_date_airline.text= date!![0]
                tv_airport_code.text=item.airportName
                itemView.setOnClickListener {
                    onItemClickCallback?.onItemClicked(item)
                }
            }
        }
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: DeliverAirlineEntity)
    }
}