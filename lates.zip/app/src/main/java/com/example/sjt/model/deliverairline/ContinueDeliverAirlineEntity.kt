package com.example.sjt.model.deliverairline

data class ContinueDeliverAirlineEntity(
    val error: Boolean? = null,
    val message: String? = null
)