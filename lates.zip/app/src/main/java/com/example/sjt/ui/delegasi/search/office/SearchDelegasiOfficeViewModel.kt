package com.example.sjt.ui.delegasi.search.office

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.newpo.NewpoEntity

class SearchDelegasiOfficeViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getItemDelegasiOffice(context: Context): LiveData<List<NewpoEntity>> =
        sjtRepository.getResponseDelegasiOffice(context)
}