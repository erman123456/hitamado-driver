package com.example.sjt.ui.detail.search.airline.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.sjt.R
import com.example.sjt.model.airline.AirlineEntity
import com.example.sjt.model.airline.operational.DataItem
import kotlinx.android.synthetic.main.item_airline.view.*
import kotlinx.android.synthetic.main.item_delivery.view.*

class SearchAirlineItemHeadAdapter :
    RecyclerView.Adapter<SearchAirlineItemHeadAdapter.SearchItemViewHolder>() {

    private var onItemClickCallback: OnItemClickCallback? = null
    private var listItems = ArrayList<DataItem>()
    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    fun setListItems(listData: List<DataItem>?) {
        if (listData == null) return
        listItems.clear()
        listItems.addAll(listData)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SearchAirlineItemHeadAdapter.SearchItemViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.item_airline, parent, false)
        return SearchItemViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: SearchAirlineItemHeadAdapter.SearchItemViewHolder,
        position: Int
    ) {
        val item = listItems[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int = listItems.size

    inner class SearchItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(item: DataItem) {
            with(itemView) {
                tv_po_master_number.text = item?.poMasterNumber
                itemView.setOnClickListener {
                    onItemClickCallback?.onItemClicked(item)
                }
            }
        }
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: DataItem)
    }
}