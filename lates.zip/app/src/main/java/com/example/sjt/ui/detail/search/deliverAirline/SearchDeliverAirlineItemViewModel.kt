package com.example.sjt.ui.detail.search.deliverAirline

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.deliverairline.DeliverAirlineEntity

class SearchDeliverAirlineItemViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getItemDeliverAirline(context: Context): LiveData<List<DeliverAirlineEntity>> =
        sjtRepository.getResponseDeliverAirline(context)

    fun getItemDeliverAirlineDriver(context: Context): LiveData<List<DeliverAirlineEntity>> =
        sjtRepository.getResponseDeliverAirlineDriver(context)
}