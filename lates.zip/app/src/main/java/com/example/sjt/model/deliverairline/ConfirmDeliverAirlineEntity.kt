package com.example.sjt.model.deliverairline

data class ConfirmDeliverAirlineEntity(
    val success: Boolean? = null
)