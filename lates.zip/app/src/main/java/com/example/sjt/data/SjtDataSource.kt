package com.example.sjt.data

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.paging.PagedList
import com.example.sjt.model.airline.AirlineEntity
import com.example.sjt.model.airline.operational.DataItem
import com.example.sjt.model.airline.operational.Master
import com.example.sjt.model.airline.operational.ResponseSentOperational
import com.example.sjt.model.airline.operational.TotalEntity
import com.example.sjt.model.delegasi.DelegasiEntity
import com.example.sjt.model.deliverairline.ConfirmDeliverAirlineEntity
import com.example.sjt.model.deliverairline.ContinueDeliverAirlineEntity
import com.example.sjt.model.deliverairline.DeliverAirlineEntity
import com.example.sjt.model.driver.entity.DriverEntity
import com.example.sjt.model.login.LoginEntity
import com.example.sjt.model.logout.ResponseLogout
import com.example.sjt.model.newpo.NewpoEntity
import com.example.sjt.model.newpo.NewpoPostEntity
import com.example.sjt.model.office.ContinueOfficeEntity
import com.example.sjt.model.office.OfficeEntity
import com.example.sjt.model.pickup.ConfirmEntity
import com.example.sjt.model.pickup.ContinuePickupEntity
import com.example.sjt.model.pickup.PickupEntity
import com.example.sjt.model.siapantar.ConfirmSiapAntarEntity
import com.example.sjt.model.siapantar.ContinueSiapAntarEntity
import com.example.sjt.model.siapantar.ResponsePostSiapantar
import com.example.sjt.model.siapantar.SiapAntarEntity

interface SjtDataSource {
    fun getResponseLogin(email: String, password: String, deviceId: String): LiveData<LoginEntity>
    fun getResponseLogout(context: Context):LiveData<ResponseLogout>
    fun getResponsePostNewPo(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<NewpoPostEntity>

    fun getResponseNewpo(context: Context): LiveData<List<NewpoEntity>>
    fun getResponsePostDelegasiOffice(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<NewpoPostEntity>

    fun getResponseOffice(context: Context): LiveData<List<OfficeEntity>>
    fun getResponseOfficeDriver(context: Context): LiveData<List<OfficeEntity>>
    fun getResponsePostSiapantar(
        context: Context,
        mpoId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<ResponsePostSiapantar>

    fun getResponseSiapAntar(context: Context): LiveData<List<SiapAntarEntity>>
    fun getResponseSiapAntarDriver(context: Context): LiveData<List<SiapAntarEntity>>
    fun getResponsePostDelegasiSiapantar(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<NewpoPostEntity>

    fun getResponseDeliverAirline(context: Context): LiveData<List<DeliverAirlineEntity>>
    fun getResponseDeliverAirlineDriver(context: Context): LiveData<List<DeliverAirlineEntity>>
    fun getResponsePostDelegasiDeliverAirline(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<NewpoPostEntity>

    fun getDataDriver(context: Context): LiveData<List<DriverEntity>>
    fun getDataUser(context: Context): LiveData<DriverEntity>
    fun getResponsePickup(context: Context): LiveData<List<PickupEntity>>
    fun getResponseDriverPickup(context: Context): LiveData<List<PickupEntity>>
    fun getResponseConfirm(context: Context, poHouseId: String?): LiveData<ConfirmEntity>
    fun postResponseArrivedToCustomer(context: Context, poHouseId: String?): LiveData<ConfirmEntity>
    fun postResponseContinuePickup(
        context: Context,
        poHouseId: String?
    ): LiveData<ContinuePickupEntity>

    fun postResponseDelegasiPickup(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<DelegasiEntity>

    fun postArrivedAtOffice(
        context: Context,
        poHouseId: String?
    ): LiveData<com.example.sjt.model.office.ConfirmEntity>

    fun postResponseContinueOffice(
        context: Context,
        poHouseId: String?
    ): LiveData<ContinueOfficeEntity>

    fun postResponseDelegasiOffice(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<DelegasiEntity>

    fun postResponseArrivedSiapAntar(
        context: Context,
        poHouseId: String?
    ): LiveData<ConfirmSiapAntarEntity>

    fun postResponseContinueSiapAntar(
        context: Context,
        poHouseId: String?
    ): LiveData<ContinueSiapAntarEntity>

    fun postResponseDelegasiSiapAntar(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<DelegasiEntity>

    fun postArrivedDeliverAirline(
        context: Context,
        poHouseId: String?
    ): LiveData<ConfirmDeliverAirlineEntity>

    fun postResponseContinueDeliverAirline(
        context: Context,
        mpoId: String?
    ): LiveData<ContinueDeliverAirlineEntity>

    fun postResponseDelegasiDeliverAirline(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<DelegasiEntity>

    fun postCompletedAirline(
        context: Context,
        uid: String,
        weighLini: String,
        collieLini: String,
        weighLini2: String,
        collieLini2: String
    ): LiveData<ResponseSentOperational>

    fun postCompletedAirline2(
        context: Context,
        uid: String,
        weighLini: String,
        collieLini: String
    ): LiveData<ResponseSentOperational>

    fun getResponseDelegasiPickup(context: Context): LiveData<List<NewpoEntity>>
    fun getResponseDelegasiOffice(context: Context): LiveData<List<NewpoEntity>>
    fun getResponseDelegasiSiapantar(context: Context): LiveData<List<NewpoEntity>>
    fun getResponseDelegasiDeliverAirline(context: Context): LiveData<List<SiapAntarEntity>>
    fun getResponseAirline(context: Context): LiveData<List<AirlineEntity>>
    fun getResponseOperationalAirline(context: Context): LiveData<PagedList<DataItem>>
    fun getResponseTotalItemAirline(context: Context):LiveData<TotalEntity>
    fun getResponseSearchAirline(context: Context,mpoId: String?):LiveData<DataItem>
}