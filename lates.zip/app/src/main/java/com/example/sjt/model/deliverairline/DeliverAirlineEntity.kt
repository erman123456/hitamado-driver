package com.example.sjt.model.deliverairline

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class DeliverAirlineEntity(
    val uid: String?,
    val po_master_number: String?,
    val airportName:String?,
    val driverName:String?,
    val dateDelivery:String?,
    val quantity_est: String?,
    val collie_est: String?
) : Parcelable