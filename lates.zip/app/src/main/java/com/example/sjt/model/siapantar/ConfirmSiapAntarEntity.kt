package com.example.sjt.model.siapantar

data class ConfirmSiapAntarEntity(
    val success: Boolean? = null
)