package com.example.sjt.model.newpo

data class NewpoPostEntity(
    val success: Boolean? = null
)