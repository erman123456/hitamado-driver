package com.example.sjt.ui.account

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.driver.entity.DriverEntity
import com.example.sjt.model.logout.ResponseLogout

class AccountViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getDataUser(context: Context): LiveData<DriverEntity> = sjtRepository.getDataUser(context)
    fun doLogout(context: Context):LiveData<ResponseLogout> = sjtRepository.getResponseLogout(context)
}