package com.example.sjt.model.pickup

data class ConfirmEntity(
    val confirmed: Boolean? = null
)