package com.example.sjt.model.login

data class ResponseLogin(
	val uid: String? = null,
	val jabatan: String? = null,
	val token: String? = null
)
