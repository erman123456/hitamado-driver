package com.example.sjt.ui.home

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.driver.entity.DriverEntity
import com.example.sjt.model.newpo.NewpoEntity

class HomeViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getItemsNewpo(context: Context): LiveData<List<NewpoEntity>> =
        sjtRepository.getResponseNewpo(context)

    fun getDataUser(context: Context): LiveData<DriverEntity> = sjtRepository.getDataUser(context)
}