package com.example.sjt.model.airline.operational

data class TotalEntity(
    val total: Int?
)