package com.example.sjt.ui.delegasi.search.pickup

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.newpo.NewpoEntity

class SearchDelegasiPickupViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getItemDelegasiPickup(context: Context): LiveData<List<NewpoEntity>> =
        sjtRepository.getResponseDelegasiPickup(context)
}