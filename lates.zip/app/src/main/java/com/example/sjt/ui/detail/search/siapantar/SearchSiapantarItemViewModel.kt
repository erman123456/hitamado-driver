package com.example.sjt.ui.detail.search.siapantar

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.siapantar.SiapAntarEntity

class SearchSiapantarItemViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getItemSiapAntar(context: Context): LiveData<List<SiapAntarEntity>> =
        sjtRepository.getResponseSiapAntar(context)

    fun getItemSiapAntarDriver(context: Context): LiveData<List<SiapAntarEntity>> =
        sjtRepository.getResponseSiapAntarDriver(context)
}