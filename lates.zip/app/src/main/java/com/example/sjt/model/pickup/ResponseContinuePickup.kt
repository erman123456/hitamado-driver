package com.example.sjt.model.pickup

import com.google.gson.annotations.SerializedName

data class ResponseContinuePickup(
    @field:SerializedName("confirmed")
    val success: Boolean? = null
)