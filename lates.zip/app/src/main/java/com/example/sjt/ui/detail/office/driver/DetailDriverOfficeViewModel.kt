package com.example.sjt.ui.detail.office.driver

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.delegasi.DelegasiEntity
import com.example.sjt.model.office.ConfirmEntity
import com.example.sjt.model.office.ContinueOfficeEntity

class DetailDriverOfficeViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun postArrivedOffice(context: Context, poHouseId: String?): LiveData<ConfirmEntity> =
        sjtRepository.postArrivedAtOffice(context, poHouseId)

    fun postContinueOffice(context: Context, poHouseId: String?): LiveData<ContinueOfficeEntity> =
        sjtRepository.postResponseContinueOffice(context, poHouseId)

    fun postDelegasiOffice(
        context: Context,
        poHouseId: String?,
        driverUid: String?,
        description: String?
    ): LiveData<DelegasiEntity> =
        sjtRepository.postResponseDelegasiOffice(context, poHouseId, driverUid, description)
}