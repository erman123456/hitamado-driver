package com.example.sjt.model.siapantar

data class ContinueSiapAntarEntity(
    val success: Boolean? = null
)