package com.example.sjt.data.api

import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiConfig {
    companion object {
        var gson = GsonBuilder()
            .setLenient()
            .create()

        fun getApiService(): ApiService {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://combine.sjtransindo.lunata.co.id/api/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
            return retrofit.create(ApiService::class.java)
        }
    }
}