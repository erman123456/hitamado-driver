package com.example.sjt.model.office

data class ContinueOfficeEntity(
    val success: Boolean? = null
)