package com.example.sjt.ui.detail.search.pickup

import android.content.Context
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.pickup.PickupEntity

class SearchPickupItemViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun getItemPickup(context: Context): LiveData<List<PickupEntity>> =
        sjtRepository.getResponsePickup(context)

    fun getItemDriverPickup(context: Context): LiveData<List<PickupEntity>> =
        sjtRepository.getResponseDriverPickup(context)
}