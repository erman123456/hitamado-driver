package com.example.sjt.di

import android.content.Context
import com.example.sjt.data.SjtRepository
import com.example.sjt.data.remote.RemoteDataSource
import com.example.sjt.data.remote.page.OperationalPageDataSource
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ApplicationComponent
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Singleton

@Module
@InstallIn(ApplicationComponent::class)
class AppModule {
    @Singleton
    @Provides
    fun provideSjtRepository(remoteDataSource: RemoteDataSource): SjtRepository =
        SjtRepository(remoteDataSource)

    @Provides
    fun provideRemoteDataSource(): RemoteDataSource = RemoteDataSource()

    @Provides
    fun provideContext(@ApplicationContext context: Context): Context = context

    @Provides
    fun provideOperationalPageDataSource(
        remoteDataSource: RemoteDataSource,
        context: Context
    ): OperationalPageDataSource = OperationalPageDataSource(remoteDataSource, context)
}