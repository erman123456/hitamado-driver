package com.example.sjt.ui.login

import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.example.sjt.data.SjtRepository
import com.example.sjt.model.login.LoginEntity

class LoginViewModel @ViewModelInject constructor(private val sjtRepository: SjtRepository) :
    ViewModel() {
    fun doLogin(email: String, password: String, deviceId: String): LiveData<LoginEntity> =
        sjtRepository.getResponseLogin(email, password, deviceId)
}